import numpy as np
import pandas as pd
import xgboost as xgb
from typing import Dict
from sklearn.decomposition import IncrementalPCA
from collections import deque
from scipy.stats import wasserstein_distance
from typing import Dict, List, Tuple, Any


class RiverCompatiblePCA:
    """
    A wrapper that makes Scikit-Learn's IncrementalPCA stream-capable.
    
    SOLUTION FOR VALUE ERROR:
    It uses an internal buffer to ensure that ‘partial_fit’
    always receives enough data points (at least n_components).
    """
    def __init__(self, n_components: int):
        self.n_components = n_components
        self.pca = IncrementalPCA(n_components=n_components)
        self.is_fitted = False
        self.feature_names = None
        
        # Buffer for Mini-Batches
        self.buffer = []
        
    def learn_one(self, x: Dict[str, float]):
        """
        Collects data points and trains the PCA as soon as there is enough data in the buffer.
        """
        # 1. Keep feature names consistent
        if self.feature_names is None:
            self.feature_names = sorted(list(x.keys()))
        
        # 2. Extract values and push to buffer
        vals = [x[k] for k in self.feature_names]
        self.buffer.append(vals)
        
        # 3. Check: Do we have enough data for an update?
        # Scikit-Learn requires: n_samples >= n_components
        # We take n_components or at least 5 samples to be safe
        min_batch_size = max(self.n_components, 5)
        
        if len(self.buffer) >= min_batch_size:
            X_batch = np.array(self.buffer)
            
            # Now call partial_fit safely
            self.pca.partial_fit(X_batch)
            self.is_fitted = True
            
            # Clear buffer for the next round
            self.buffer = []

    def transform_one(self, x: Dict[str, float]) -> Dict[int, float]:
        """
        Transforms a data point. If PCA is not yet trained (buffer is still filling), zeros are returned.
        """
        if not self.is_fitted:
            # As long as we are collecting the first few points, we cannot project anything yet.
            # We return 0.0 ("No signal").
            return {i: 0.0 for i in range(self.n_components)}
        
        # Ensure the same order
        vals = [x[k] for k in self.feature_names]
        X_batch = np.array([vals])
        
        # Transform
        X_transformed = self.pca.transform(X_batch)
        
        # Format back into a Dict
        return {i: val for i, val in enumerate(X_transformed[0])}


class AdaptiveModel:
    """
    Wrapper around XGBoost that allows for full retraining on new data chunks.
    Acts as the 'Patient' in our experiment.
    """
    def __init__(self, params: Dict[str, Any] = None):
        # Default parameters for a robust regression model
        if params is None:
            self.params = {
                "n_estimators": 100,
                "max_depth": 6,
                "learning_rate": 0.1,
                "objective": "reg:squarederror",
                "n_jobs": -1,
                "verbosity": 0
            }
        else:
            self.params = params
            
        self.model = None
        self.is_fitted = False

    def train(self, X: pd.DataFrame, y: pd.Series):
        """
        Trains or retrains the model from scratch using the provided data.
        """
        self.model = xgb.XGBRegressor(**self.params)
        self.model.fit(X, y)
        self.is_fitted = True

    def predict(self, X: pd.DataFrame) -> np.ndarray:
        """
        Generates predictions. Returns zeros if model is not yet fitted (cold start).
        """
        if not self.is_fitted:
            return np.zeros(len(X))
        return self.model.predict(X)
    
    def update(self, X_new: pd.DataFrame, y_new: pd.Series):
        """
        Triggers a retraining process on the provided window of data.
        """
        self.train(X_new, y_new)

class GroupedWassersteinDetector:
    """
    System 3: Monitors feature groups using the Wasserstein Distance.
    
    Logic:
    1. Holds a reference distribution (aggregated per group) from training data.
    2. Maintains a sliding window of the incoming stream.
    3. Computes Wasserstein distance between Reference and Current Window for each group.
    4. Alarms if distance > threshold.
    """
    def __init__(self, feature_groups: Dict[str, List[str]], window_size: int = 500, threshold: float = 0.1):
        self.groups = feature_groups
        self.window_size = window_size
        self.threshold = threshold
        
        # Sliding window storage
        self.current_window = deque(maxlen=window_size)
        
        # Reference statistics (Mean aggregation of training data per group)
        self.reference_stats = {} 
        self.is_initialized = False

    def fit_reference(self, X_ref: pd.DataFrame):
        """
        Learns the baseline distribution from the initial training set or after retraining.
        Aggregates features within a group to a single signal (Mean).
        """
        self.reference_stats = {}
        for group_name, cols in self.groups.items():
            # Filter for columns present in the dataframe
            valid_cols = [c for c in cols if c in X_ref.columns]
            if not valid_cols:
                continue
            
            # Aggregate group to 1D signal (Mean)
            group_signal = X_ref[valid_cols].mean(axis=1).values
            self.reference_stats[group_name] = group_signal
            
        self.is_initialized = True

    def update(self, x_new: pd.Series) -> Tuple[bool, Dict[str, float]]:
        """
        Processes a new data row.
        
        Returns:
            is_alarm (bool): True if any group exceeds the threshold.
            details (dict): Calculated distances per group (for interpretability/RO3).
        """
        if not self.is_initialized:
            return False, {}
            
        self.current_window.append(x_new)
        
        # Only check for drift if window is full
        if len(self.current_window) < self.window_size:
            return False, {}
        
        # Convert deque to numpy array ONCE for all groups (vectorized)
        window_array = np.array([list(row) for row in self.current_window])
        window_df = pd.DataFrame(window_array, columns=list(self.current_window[0].index))
        
        group_distances = {}
        alarm = False
        
        for group_name, ref_signal in self.reference_stats.items():
            cols = self.groups[group_name]
            valid_cols = [c for c in cols if c in window_df.columns]
            
            if not valid_cols:
                continue
            
            # Vectorized mean computation across the window
            curr_signal = window_df[valid_cols].mean(axis=1).values
            
            # Compute Wasserstein Distance (Distribution Shift)
            wd = wasserstein_distance(ref_signal, curr_signal)
            group_distances[group_name] = wd
            
            # Threshold Check
            if wd > self.threshold:
                alarm = True
                
        return alarm, group_distances